`timescale 1ns / 1ps
//------------------------------------------------------------------
// Optional testbench for Lab8_FPGA_top (uses defparam to shorten the
// debounce time of the stand-in debouncer so simulation is fast)
//------------------------------------------------------------------
module Lab8_FPGA_top_tb;
    reg clk = 0, btnC = 0, btnD = 0;
    reg [15:0] switches = 0;
    wire [15:0] leds;
    integer pass_count = 0, fail_count = 0;

    Lab8_FPGA_top dut (.clk(clk), .switches(switches), .btnC(btnC), .btnD(btnD), .leds(leds));
    defparam dut.db_step.CYCLES = 4;
    defparam dut.db_rst.CYCLES  = 4;

    always #5 clk = ~clk;

    task press(input integer which);   // 0 = step, 1 = reset
        begin
            if (which == 0) btnC = 1; else btnD = 1;
            repeat (20) @(posedge clk);
            btnC = 0; btnD = 0;
            repeat (20) @(posedge clk);
        end
    endtask

    task check(input [8*24-1:0] name, input [15:0] exp);
        begin
            if (leds === exp) begin pass_count = pass_count + 1; $display("PASS %-24s leds=%h", name, leds); end
            else begin fail_count = fail_count + 1; $display("FAIL %-24s leds=%h expected=%h", name, leds, exp); end
        end
    endtask

    initial begin
        $dumpfile("Lab8_FPGA_top.vcd");
        $dumpvars(0, Lab8_FPGA_top_tb);
        switches = 16'hA5C3;
        press(1);                                   // reset
        check("after reset", 16'h0000);

        press(0); check("press1: LEDs = switches", 16'hA5C3);
        switches = 16'h1234;                        // change switches: must not matter now
        press(0); check("press2: LEDs unchanged", 16'hA5C3);
        if (dut.u_mem_sys.u_mem.mem[5] === 32'hA5C35A3C) begin pass_count = pass_count + 1; $display("PASS mem[5] = A5C35A3C"); end
        else begin fail_count = fail_count + 1; $display("FAIL mem[5] = %h", dut.u_mem_sys.u_mem.mem[5]); end
        press(0); check("press3: low half  (~sw)", 16'h5A3C);
        press(0); check("press4: high half (sw)",  16'hA5C3);
        press(0); check("press5: wraps, new sw",   16'h1234);
        press(1); check("reset clears LEDs",       16'h0000);

        $display("--------------------------------------------");
        $display("Tests passed: %0d   Tests failed: %0d", pass_count, fail_count);
        if (fail_count == 0) $display("ALL TESTS PASSED"); else $display("SOME TESTS FAILED");
        $finish;
    end
endmodule
