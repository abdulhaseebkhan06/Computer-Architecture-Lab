`timescale 1ns / 1ps
//------------------------------------------------------------------
// Self-checking testbench for the memory system (addressDecoderTop)
//------------------------------------------------------------------
module MemorySystem_tb;
    reg         clk = 0, rst = 0;
    reg  [31:0] address = 0, writeData = 0;
    reg         readEnable = 0, writeEnable = 0;
    reg  [15:0] switches = 0;
    wire [31:0] readData;
    wire [15:0] leds;

    integer pass_count = 0, fail_count = 0;
    reg [31:0] rd;

    addressDecoderTop dut (
        .clk(clk), .rst(rst), .address(address),
        .readEnable(readEnable), .writeEnable(writeEnable),
        .writeData(writeData), .switches(switches),
        .readData(readData), .leds(leds));

    always #5 clk = ~clk;

    // ---------- bus helpers (drive on falling edge, device samples on rising edge) ----------
    task bus_write(input [31:0] a, input [31:0] d);
        begin
            @(negedge clk);
            address = a; writeData = d; writeEnable = 1; readEnable = 0;
            @(negedge clk);
            writeEnable = 0;
        end
    endtask

    task bus_read(input [31:0] a, output [31:0] d);
        begin
            @(negedge clk);
            address = a; readEnable = 1; writeEnable = 0;
            #2 d = readData;
            @(negedge clk);
            readEnable = 0;
        end
    endtask

    task check32(input [8*28-1:0] name, input [31:0] got, input [31:0] exp);
        begin
            if (got === exp) begin
                pass_count = pass_count + 1;
                $display("PASS %-28s got=%h", name, got);
            end else begin
                fail_count = fail_count + 1;
                $display("FAIL %-28s got=%h expected=%h", name, got, exp);
            end
        end
    endtask

    // ---------- stand-alone decoder used for the exhaustive address check ----------
    reg  [9:0] d_addr = 0;
    reg        d_re = 0, d_we = 0;
    wire dm_sel, led_sel, sw_sel, dm_w, dm_r, led_w, sw_r;
    AddressDecoder dec_chk (
        .address(d_addr), .readEnable(d_re), .writeEnable(d_we),
        .DataMemSelect(dm_sel), .LEDSelect(led_sel), .SwitchSelect(sw_sel),
        .DataMemWrite(dm_w), .DataMemRead(dm_r),
        .LEDWrite(led_w), .SwitchReadEnable(sw_r));

    integer a, k, dec_errors;
    reg exp_dm, exp_led, exp_sw;

    initial begin
        $dumpfile("MemorySystem.vcd");
        $dumpvars(0, MemorySystem_tb);
        #20;

        // ---------------- 1. Data memory write / read ----------------
        $display("--- Data memory ---");
        bus_write(0,   32'hDEADBEEF);
        bus_write(1,   32'hCAFEBABE);
        bus_write(255, 32'h12345678);
        bus_write(256, 32'h0BADF00D);   // address bit 8 set, still data memory
        bus_write(511, 32'hFFFF0000);   // last data-memory word
        bus_read(0,   rd); check32("mem[0]",   rd, 32'hDEADBEEF);
        bus_read(1,   rd); check32("mem[1]",   rd, 32'hCAFEBABE);
        bus_read(255, rd); check32("mem[255]", rd, 32'h12345678);
        bus_read(256, rd); check32("mem[256]", rd, 32'h0BADF00D);
        bus_read(511, rd); check32("mem[511]", rd, 32'hFFFF0000);
        bus_write(1, 32'h11112222);     // overwrite
        bus_read(1,  rd); check32("mem[1] overwritten", rd, 32'h11112222);
        bus_read(0,  rd); check32("mem[0] untouched",   rd, 32'hDEADBEEF);
        bus_read(2,  rd); check32("mem[2] never written", rd, 32'h0);

        // ---------------- 2. LED writes ----------------
        $display("--- LEDs ---");
        bus_write(512, 32'hABCD1234);
        check32("LEDs after write @512", {16'b0, leds}, 32'h00001234);
        bus_write(700, 32'h0000FFFF);   // any address inside 512..767
        check32("LEDs after write @700", {16'b0, leds}, 32'h0000FFFF);
        bus_write(767, 32'h0000A55A);   // last LED address
        check32("LEDs after write @767", {16'b0, leds}, 32'h0000A55A);
        bus_read(0, rd); check32("mem[0] unchanged by LED wr", rd, 32'hDEADBEEF);
        bus_read(256, rd); check32("mem[256] unchanged by LED", rd, 32'h0BADF00D);
        bus_write(3, 32'h55555555);     // memory write must not touch LEDs
        check32("LEDs unchanged by mem write", {16'b0, leds}, 32'h0000A55A);

        // ---------------- 3. Switch reads ----------------
        $display("--- Switches ---");
        switches = 16'hA5A5; bus_read(768,  rd); check32("switch read @768",  rd, 32'h0000A5A5);
        switches = 16'h0F0F; bus_read(1023, rd); check32("switch read @1023", rd, 32'h00000F0F);
        switches = 16'hFFFF; bus_read(900,  rd); check32("switch read @900",  rd, 32'h0000FFFF);

        // ---------------- 4. Access-type restrictions ----------------
        $display("--- Read-only / write-only ---");
        bus_write(768, 32'h12345678);   // switches are read only: ignored
        check32("write to switch: LEDs same", {16'b0, leds}, 32'h0000A55A);
        bus_read(0, rd); check32("write to switch: mem same", rd, 32'hDEADBEEF);
        switches = 16'h3C3C; bus_read(768, rd); check32("switch still reads", rd, 32'h00003C3C);
        bus_read(512, rd); check32("read from LED region = 0", rd, 32'h0);

        // ---------------- 5. Only the 10 LSBs are decoded ----------------
        $display("--- Upper address bits ignored ---");
        bus_write(32'h10010004, 32'h600DC0DE);
        bus_read(4, rd);              check32("alias write -> mem[4]", rd, 32'h600DC0DE);
        bus_write(32'h10010200, 32'h00000BEE);
        check32("alias write -> LEDs", {16'b0, leds}, 32'h00000BEE);

        // ---------------- 6. Exhaustive decoder check ----------------
        $display("--- Exhaustive decoder check (1024 addresses x 4 enable combos) ---");
        dec_errors = 0;
        for (a = 0; a < 1024; a = a + 1) begin
            exp_dm  = (a >= 0)   && (a <= 511);
            exp_led = (a >= 512) && (a <= 767);
            exp_sw  = (a >= 768) && (a <= 1023);
            for (k = 0; k < 4; k = k + 1) begin
                d_addr = a[9:0]; d_re = k[0]; d_we = k[1];
                #1;
                if (dm_sel !== exp_dm || led_sel !== exp_led || sw_sel !== exp_sw ||
                    dm_w   !== (exp_dm  & d_we) || dm_r !== (exp_dm & d_re) ||
                    led_w  !== (exp_led & d_we) || sw_r !== (exp_sw & d_re) ||
                    (dm_sel + led_sel + sw_sel) !== 1)           // exactly one device
                    dec_errors = dec_errors + 1;
            end
        end
        if (dec_errors == 0) begin
            pass_count = pass_count + 1;
            $display("PASS decoder: only the correct device enabled for all 4096 cases");
        end else begin
            fail_count = fail_count + 1;
            $display("FAIL decoder: %0d wrong cases", dec_errors);
        end

        // ---------------- 7. Reset ----------------
        $display("--- Reset ---");
        @(negedge clk); rst = 1;
        @(negedge clk); rst = 0;
        check32("LEDs cleared by reset", {16'b0, leds}, 32'h0);
        bus_read(0, rd); check32("mem[0] kept after reset", rd, 32'hDEADBEEF);

        #20;
        $display("--------------------------------------------");
        $display("Tests passed: %0d   Tests failed: %0d", pass_count, fail_count);
        if (fail_count == 0) $display("ALL TESTS PASSED");
        else                 $display("SOME TESTS FAILED");
        $finish;
    end
endmodule
