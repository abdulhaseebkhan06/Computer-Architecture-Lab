`timescale 1ns / 1ps
//------------------------------------------------------------------
// Data memory: 512 words x 32 bits  (CPU addresses 0..511)
//   - synchronous write (rising clock edge, when MemWrite = 1)
//   - asynchronous (combinational) read, as needed by a single-cycle CPU
//------------------------------------------------------------------
module DataMemory (
    input         clk,
    input         MemWrite,
    input  [8:0]  address,        // word index 0..511
    input  [31:0] write_data,
    output [31:0] read_data
);
    reg [31:0] mem [0:511];

    integer i;
    initial begin
        for (i = 0; i < 512; i = i + 1)
            mem[i] = 32'b0;       // known contents at power-up / simulation start
    end

    always @(posedge clk)
        if (MemWrite)
            mem[address] <= write_data;

    assign read_data = mem[address];
endmodule
