`timescale 1ns / 1ps
//------------------------------------------------------------------
// Lab 8, Task 3 - FPGA top level (Basys 3)
// A small FSM plays the role of the CPU and performs memory-mapped
// reads and writes through addressDecoderTop.
//
//  btnC = step (one press runs the next phase)   btnD = reset
//
//  Press 1 (phase 0): READ  switches (addr 768) -> WRITE LEDs (addr 512)
//  Press 2 (phase 1): WRITE data memory word 5 = {sw, ~sw}  (LEDs unchanged)
//  Press 3 (phase 2): READ  mem[5] -> WRITE LEDs with low half  (= ~sw)
//  Press 4 (phase 3): READ  mem[5] -> WRITE LEDs with high half (=  sw)
//  Press 5 starts again at phase 0.
//------------------------------------------------------------------
module Lab8_FPGA_top (
    input         clk,            // 100 MHz
    input  [15:0] switches,
    input         btnC,           // step
    input         btnD,           // reset
    output [15:0] leds
);
    localparam [31:0] SWITCH_ADDR = 32'd768;
    localparam [31:0] LED_ADDR    = 32'd512;
    localparam [31:0] MEM_ADDR    = 32'd5;

    // ---------- buttons: debounce, then one-pulse per press ----------
    wire step_db, rst;
    debouncer db_step (.clk(clk), .pbin(btnC), .pbout(step_db));
    debouncer db_rst  (.clk(clk), .pbin(btnD), .pbout(rst));

    reg step_d = 1'b0;
    always @(posedge clk) step_d <= step_db;
    wire step = step_db & ~step_d;

    // ---------- 2-FF synchroniser for the slide switches ----------
    reg [15:0] sw_m = 16'b0, sw_s = 16'b0;
    always @(posedge clk) begin
        sw_m <= switches;
        sw_s <= sw_m;
    end

    // ---------- memory system (the "bus") ----------
    reg  [31:0] address;
    reg         readEnable, writeEnable;
    reg  [31:0] writeData;
    wire [31:0] readData;

    addressDecoderTop u_mem_sys (
        .clk(clk), .rst(rst),
        .address(address),
        .readEnable(readEnable), .writeEnable(writeEnable),
        .writeData(writeData),
        .switches(sw_s),
        .readData(readData),
        .leds(leds)
    );

    // ---------- FSM ----------
    localparam [1:0] S_WAIT   = 2'd0,   // wait for a button press
                     S_RD     = 2'd1,   // one bus read
                     S_WR_LED = 2'd2,   // one bus write to the LEDs
                     S_WR_MEM = 2'd3;   // one bus write to data memory

    reg [1:0]  state   = S_WAIT;
    reg [1:0]  phase   = 2'd0;
    reg [15:0] tmp     = 16'b0;         // switch value captured in phase 0
    reg [31:0] rd_data = 32'b0;         // last value read from the bus

    // outputs of the FSM = bus signals (depend only on state/phase)
    always @(*) begin
        address     = 32'b0;
        readEnable  = 1'b0;
        writeEnable = 1'b0;
        writeData   = 32'b0;
        case (state)
            S_RD: begin
                readEnable = 1'b1;
                address    = (phase == 2'd0) ? SWITCH_ADDR : MEM_ADDR;
            end
            S_WR_LED: begin
                writeEnable = 1'b1;
                address     = LED_ADDR;
                writeData   = (phase == 2'd3) ? {16'b0, rd_data[31:16]}
                                              : {16'b0, rd_data[15:0]};
            end
            S_WR_MEM: begin
                writeEnable = 1'b1;
                address     = MEM_ADDR;
                writeData   = {tmp, ~tmp};
            end
            default: ;
        endcase
    end

    // state register
    always @(posedge clk) begin
        if (rst) begin
            state   <= S_WAIT;
            phase   <= 2'd0;
            tmp     <= 16'b0;
            rd_data <= 32'b0;
        end else begin
            case (state)
                S_WAIT: if (step)
                            state <= (phase == 2'd1) ? S_WR_MEM : S_RD;
                S_RD: begin
                    rd_data <= readData;
                    if (phase == 2'd0) tmp <= readData[15:0];
                    state <= S_WR_LED;
                end
                S_WR_LED: begin
                    state <= S_WAIT;
                    phase <= phase + 2'd1;    // wraps 3 -> 0
                end
                S_WR_MEM: begin
                    state <= S_WAIT;
                    phase <= phase + 2'd1;
                end
            endcase
        end
    end
endmodule
