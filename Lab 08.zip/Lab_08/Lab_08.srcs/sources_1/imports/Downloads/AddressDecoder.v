`timescale 1ns / 1ps
//------------------------------------------------------------------
// Address decoder (pure combinational logic)
//   0..511     Data memory   (address[9] = 0)
//   512..767   LEDs          (address[9:8] = 10)   write only
//   768..1023  Switches      (address[9:8] = 11)   read only
// Only the 10 LSBs of the CPU address are used.
//------------------------------------------------------------------
module AddressDecoder (
    input  [9:0] address,
    input        readEnable,
    input        writeEnable,
    // device select lines
    output       DataMemSelect,
    output       LEDSelect,
    output       SwitchSelect,
    // qualified enables sent to the devices
    output       DataMemWrite,
    output       DataMemRead,
    output       LEDWrite,
    output       SwitchReadEnable
);
    assign DataMemSelect = ~address[9];
    assign LEDSelect     =  address[9] & ~address[8];
    assign SwitchSelect  =  address[9] &  address[8];

    assign DataMemWrite     = DataMemSelect & writeEnable;
    assign DataMemRead      = DataMemSelect & readEnable;
    assign LEDWrite         = LEDSelect     & writeEnable;   // LEDs: write only
    assign SwitchReadEnable = SwitchSelect  & readEnable;    // switches: read only
endmodule
