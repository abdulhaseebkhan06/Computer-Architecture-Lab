`timescale 1ns / 1ps
//------------------------------------------------------------------
// Memory system top module (talks directly to the processor)
//------------------------------------------------------------------
module addressDecoderTop(
    input         clk, rst,
    input  [31:0] address,
    input         readEnable, writeEnable,
    input  [31:0] writeData,
    input  [15:0] switches,
    output [31:0] readData,
    output [15:0] leds
);
    // decoder outputs
    wire DataMemSelect, LEDSelect, SwitchSelect;
    wire DataMemWrite, DataMemRead, LEDWrite, SwitchReadEnable;

    AddressDecoder u_dec (
        .address(address[9:0]),
        .readEnable(readEnable), .writeEnable(writeEnable),
        .DataMemSelect(DataMemSelect), .LEDSelect(LEDSelect), .SwitchSelect(SwitchSelect),
        .DataMemWrite(DataMemWrite), .DataMemRead(DataMemRead),
        .LEDWrite(LEDWrite), .SwitchReadEnable(SwitchReadEnable)
    );

    // data memory
    wire [31:0] mem_rdata;
    DataMemory u_mem (
        .clk(clk), .MemWrite(DataMemWrite),
        .address(address[8:0]), .write_data(writeData),
        .read_data(mem_rdata)
    );

    // LED interface (Lab 5 module named "switches": it drives the LEDs)
    switches u_led_if (
        .clk(clk), .rst(rst),
        .writeData(writeData), .writeEnable(LEDWrite), .readEnable(1'b0),
        .memAddress(address[29:0]),
        .readData(), .leds(leds)
    );

    // Switch interface (Lab 5 module named "leds": it reads the switches)
    wire [31:0] sw_rdata;
    leds u_sw_if (
        .clk(clk), .rst(rst), .btns(16'b0),
        .writeData(32'b0), .writeEnable(1'b0),
        .readEnable(SwitchReadEnable),
        .memAddress(address[29:0]),
        .switches(switches),
        .readData(sw_rdata)
    );

    // read-data multiplexer: only the selected device drives readData
    assign readData = DataMemRead       ? mem_rdata :
                      SwitchReadEnable  ? sw_rdata  : 32'b0;
endmodule
