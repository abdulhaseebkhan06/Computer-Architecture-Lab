`timescale 1ns / 1ps
//------------------------------------------------------------------
// 32-bit ALU for a single-cycle RISC-V (RV32I) processor
// Operations: ADD, SUB, AND, OR, XOR, SLL, SRL, BEQ (via Zero flag)
//------------------------------------------------------------------
module ALU (
    input  [31:0] A,            // operand A (rs1)
    input  [31:0] B,            // operand B (rs2 or immediate)
    input  [3:0]  ALUControl,   // operation select
    output reg [31:0] ALUResult,// result of the selected operation
    output        Zero          // 1 when ALUResult == 0 (used by BEQ)
);

    // ---------------- Control codes ----------------
    localparam ALU_ADD = 4'b0000;
    localparam ALU_SUB = 4'b0001;
    localparam ALU_AND = 4'b0010;
    localparam ALU_OR  = 4'b0011;
    localparam ALU_XOR = 4'b0100;
    localparam ALU_SLL = 4'b0101;
    localparam ALU_SRL = 4'b0110;
    localparam ALU_BEQ = 4'b0111;   // computes A - B, Zero tells equality

    // ---------------- B / ~B multiplexer ----------------
    // SUB and BEQ both need A - B = A + ~B + 1
    wire        sub_sel = (ALUControl == ALU_SUB) || (ALUControl == ALU_BEQ);
    wire [31:0] B_mux   = sub_sel ? ~B : B;

    // ---------------- 32-bit adder / subtractor ----------------
    wire [31:0] sum;
    wire        cout;
    assign {cout, sum} = A + B_mux + sub_sel;   // sub_sel acts as Cin

    // ---------------- Bitwise logic unit ----------------
    wire [31:0] and_res = A & B;
    wire [31:0] or_res  = A | B;
    wire [31:0] xor_res = A ^ B;

    // ---------------- Shifter ----------------
    wire [4:0]  shamt   = B[4:0];               // shift amount 0..31
    wire [31:0] sll_res = A << shamt;           // logical left
    wire [31:0] srl_res = A >> shamt;           // logical right

    // ---------------- Result multiplexer ----------------
    always @(*) begin
        case (ALUControl)
            ALU_ADD: ALUResult = sum;
            ALU_SUB: ALUResult = sum;
            ALU_BEQ: ALUResult = sum;
            ALU_AND: ALUResult = and_res;
            ALU_OR : ALUResult = or_res;
            ALU_XOR: ALUResult = xor_res;
            ALU_SLL: ALUResult = sll_res;
            ALU_SRL: ALUResult = srl_res;
            default: ALUResult = 32'b0;
        endcase
    end

    // ---------------- Zero detector ----------------
    assign Zero = (ALUResult == 32'b0);

endmodule
