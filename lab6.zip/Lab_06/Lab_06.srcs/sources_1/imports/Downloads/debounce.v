`timescale 1ns / 1ps
//------------------------------------------------------------------
// Button debouncer + one-shot pulse generator
//  - 2-FF synchroniser removes metastability
//  - 'clean' only changes after the input has been stable for
//    CYCLES clock cycles (10 ms at 100 MHz with the default)
//  - 'pulse' is high for exactly one clock on each clean rising edge
//------------------------------------------------------------------
module debounce #(
    parameter CYCLES = 1_000_000          // 10 ms @ 100 MHz
)(
    input  clk,
    input  noisy,                          // raw button
    output reg clean = 1'b0,               // debounced level
    output pulse                           // one-clock press pulse
);
    reg s0 = 1'b0, s1 = 1'b0;              // synchroniser
    reg [31:0] cnt = 32'd0;
    reg clean_d = 1'b0;

    always @(posedge clk) begin
        s0 <= noisy;
        s1 <= s0;

        if (s1 == clean)
            cnt <= 32'd0;                  // input agrees with output: nothing pending
        else begin
            cnt <= cnt + 1'b1;             // input differs: count how long
            if (cnt == CYCLES - 1) begin
                clean <= s1;               // stable long enough: accept it
                cnt   <= 32'd0;
            end
        end

        clean_d <= clean;
    end

    assign pulse = clean & ~clean_d;       // rising-edge detector
endmodule
