`timescale 1ns / 1ps
//------------------------------------------------------------------
// Switch interface: 2-FF synchroniser for the 16 slide switches
//------------------------------------------------------------------
module switch_interface (
    input             clk,
    input      [15:0] sw_in,
    output reg [15:0] sw_out = 16'd0
);
    reg [15:0] meta = 16'd0;
    always @(posedge clk) begin
        meta   <= sw_in;
        sw_out <= meta;
    end
endmodule
