`timescale 1ns / 1ps
//------------------------------------------------------------------
// Top level for Lab 6, Task 3 (Basys 3)
//   FSM: LOAD -> EXEC -> SHOW, advances on each button press
//   btnC : step / re-read switches      btnD : reset
//   sw[3:0]  : ALUControl (manual mode)
//   sw[5:4]  : page select for the 32-bit result
//   sw[15]   : 1 = auto mode (FSM cycles ADD..BEQ on each press)
//   led[15]  : Zero        led[14:0] : selected 15 bits of ALUResult
//------------------------------------------------------------------
module ALU_top #(
    parameter DEBOUNCE_CYCLES = 1_000_000
)(
    input         clk,        // 100 MHz
    input  [15:0] sw,
    input         btnC,
    input         btnD,
    output [15:0] led
);
    // Fixed operands from the lab handout
    localparam [31:0] OPERAND_A = 32'h10101010;
    localparam [31:0] OPERAND_B = 32'h01010101;

    // ---------------- Input interfaces ----------------
    wire step_pulse;
    wire rst;
    debounce #(.CYCLES(DEBOUNCE_CYCLES)) db_step (
        .clk(clk), .noisy(btnC), .clean(), .pulse(step_pulse));
    debounce #(.CYCLES(DEBOUNCE_CYCLES)) db_rst (
        .clk(clk), .noisy(btnD), .clean(rst), .pulse());

    wire [15:0] sw_s;
    switch_interface u_sw (.clk(clk), .sw_in(sw), .sw_out(sw_s));

    wire       auto_mode   = sw_s[15];
    wire [1:0] page        = sw_s[5:4];
    wire [3:0] manual_ctrl = sw_s[3:0];

    // ---------------- ALU ----------------
    reg  [3:0]  ctrl_reg = 4'd0;
    wire [31:0] alu_result;
    wire        alu_zero;

    ALU u_alu (
        .A(OPERAND_A),
        .B(OPERAND_B),
        .ALUControl(ctrl_reg),
        .ALUResult(alu_result),
        .Zero(alu_zero)
    );

    // ---------------- FSM ----------------
    localparam [1:0] S_LOAD = 2'd0,   // read switches / op counter
                     S_EXEC = 2'd1,   // let ALU settle, capture result
                     S_SHOW = 2'd2;   // display result, wait for button

    reg [1:0]  state      = S_LOAD;
    reg [2:0]  op_cnt     = 3'd0;     // 0..7 = ADD..BEQ in auto mode
    reg [31:0] result_reg = 32'd0;
    reg        zero_reg   = 1'b0;

    always @(posedge clk) begin
        if (rst) begin
            state      <= S_LOAD;
            op_cnt     <= 3'd0;
            ctrl_reg   <= 4'd0;
            result_reg <= 32'd0;
            zero_reg   <= 1'b0;
        end else begin
            case (state)
                S_LOAD: begin
                    ctrl_reg <= auto_mode ? {1'b0, op_cnt} : manual_ctrl;
                    state    <= S_EXEC;
                end
                S_EXEC: begin
                    result_reg <= alu_result;
                    zero_reg   <= alu_zero;
                    state      <= S_SHOW;
                end
                S_SHOW: begin
                    if (step_pulse) begin
                        if (auto_mode) op_cnt <= op_cnt + 1'b1;  // wraps 7 -> 0
                        state <= S_LOAD;
                    end
                end
                default: state <= S_LOAD;
            endcase
        end
    end

    // ---------------- LED mapping ----------------
    reg [14:0] result_page;
    always @(*) begin
        case (page)
            2'b00:   result_page = result_reg[14:0];
            2'b01:   result_page = result_reg[29:15];
            2'b10:   result_page = {13'b0, result_reg[31:30]};
            default: result_page = 15'b0;
        endcase
    end

    led_interface u_led (
        .clk(clk),
        .led_in({zero_reg, result_page}),
        .led_out(led)
    );
endmodule
