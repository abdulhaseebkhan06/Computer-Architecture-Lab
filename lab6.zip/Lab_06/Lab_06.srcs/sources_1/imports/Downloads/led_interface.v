`timescale 1ns / 1ps
//------------------------------------------------------------------
// LED interface: registers the LED outputs (glitch-free drive)
//------------------------------------------------------------------
module led_interface (
    input             clk,
    input      [15:0] led_in,
    output reg [15:0] led_out = 16'd0
);
    always @(posedge clk)
        led_out <= led_in;
endmodule
