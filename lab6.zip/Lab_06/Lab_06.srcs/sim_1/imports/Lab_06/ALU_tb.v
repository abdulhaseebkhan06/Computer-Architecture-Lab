`timescale 1ns / 1ps
//------------------------------------------------------------------
// Self-checking testbench for ALU.v
//------------------------------------------------------------------
module ALU_tb;

    // ---------------- DUT signals ----------------
    reg  [31:0] A, B;
    reg  [3:0]  ALUControl;
    wire [31:0] ALUResult;
    wire        Zero;

    // ---------------- Control codes (must match ALU.v) ----------------
    localparam ALU_ADD = 4'b0000;
    localparam ALU_SUB = 4'b0001;
    localparam ALU_AND = 4'b0010;
    localparam ALU_OR  = 4'b0011;
    localparam ALU_XOR = 4'b0100;
    localparam ALU_SLL = 4'b0101;
    localparam ALU_SRL = 4'b0110;
    localparam ALU_BEQ = 4'b0111;

    integer pass_count = 0;
    integer fail_count = 0;

    // ---------------- Device under test ----------------
    ALU dut (
        .A(A), .B(B),
        .ALUControl(ALUControl),
        .ALUResult(ALUResult),
        .Zero(Zero)
    );

    // ---------------- Check task ----------------
    // Applies one test vector, waits, compares with expected values
    task check;
        input [8*10-1:0] name;
        input [3:0]      ctrl;
        input [31:0]     a_in;
        input [31:0]     b_in;
        input [31:0]     exp_result;
        input            exp_zero;
        begin
            ALUControl = ctrl;
            A = a_in;
            B = b_in;
            #10;
            if (ALUResult === exp_result && Zero === exp_zero) begin
                pass_count = pass_count + 1;
                $display("PASS %-10s A=%h B=%h -> Result=%h Zero=%b",
                         name, A, B, ALUResult, Zero);
            end else begin
                fail_count = fail_count + 1;
                $display("FAIL %-10s A=%h B=%h -> Result=%h Zero=%b (expected %h, %b)",
                         name, A, B, ALUResult, Zero, exp_result, exp_zero);
            end
        end
    endtask

    // ---------------- Stimulus ----------------
    initial begin
        $dumpfile("ALU.vcd");
        $dumpvars(0, ALU_tb);

        A = 0; B = 0; ALUControl = 0;
        #10;

        // ADD
        check("ADD",       ALU_ADD, 32'd10,       32'd20,       32'd30,       1'b0);
        check("ADD wrap",  ALU_ADD, 32'hFFFFFFFF, 32'd1,        32'd0,        1'b1);
        check("ADD zero",  ALU_ADD, 32'd5,        -32'd5,       32'd0,        1'b1);

        // SUB
        check("SUB",       ALU_SUB, 32'd50,       32'd20,       32'd30,       1'b0);
        check("SUB neg",   ALU_SUB, 32'd20,       32'd50,       -32'd30,      1'b0);
        check("SUB equal", ALU_SUB, 32'hDEADBEEF, 32'hDEADBEEF, 32'd0,        1'b1);

        // AND / OR / XOR
        check("AND",       ALU_AND, 32'hF0F0F0F0, 32'hFF00FF00, 32'hF000F000, 1'b0);
        check("AND zero",  ALU_AND, 32'hAAAAAAAA, 32'h55555555, 32'd0,        1'b1);
        check("OR",        ALU_OR,  32'hF0F0F0F0, 32'h0F0F0F0F, 32'hFFFFFFFF, 1'b0);
        check("XOR",       ALU_XOR, 32'hFFFF0000, 32'hFF00FF00, 32'h00FFFF00, 1'b0);
        check("XOR same",  ALU_XOR, 32'h12345678, 32'h12345678, 32'd0,        1'b1);

        // SLL / SRL (shift amount = B[4:0])
        check("SLL by 4",  ALU_SLL, 32'h0000000F, 32'd4,        32'h000000F0, 1'b0);
        check("SLL by 0",  ALU_SLL, 32'h12345678, 32'd0,        32'h12345678, 1'b0);
        check("SLL by 31", ALU_SLL, 32'h00000001, 32'd31,       32'h80000000, 1'b0);
        check("SRL by 4",  ALU_SRL, 32'hF0000000, 32'd4,        32'h0F000000, 1'b0);
        check("SRL by 31", ALU_SRL, 32'h80000000, 32'd31,       32'h00000001, 1'b0);
        check("SRL big B", ALU_SRL, 32'h00000100, 32'h00000028, 32'h00000001, 1'b0); // only B[4:0]=8 used

        // BEQ (Zero = 1 means branch taken)
        check("BEQ equal", ALU_BEQ, 32'd77,       32'd77,       32'd0,        1'b1);
        check("BEQ diff",  ALU_BEQ, 32'd77,       32'd78,       -32'd1,       1'b0);

        // Undefined control code -> result 0
        check("Invalid",   4'b1111, 32'h12345678, 32'h9ABCDEF0, 32'd0,        1'b1);

        // ---------------- Summary ----------------
        $display("--------------------------------------------");
        $display("Tests passed: %0d   Tests failed: %0d", pass_count, fail_count);
        if (fail_count == 0) $display("ALL TESTS PASSED");
        else                 $display("SOME TESTS FAILED");
        $finish;
    end

endmodule
