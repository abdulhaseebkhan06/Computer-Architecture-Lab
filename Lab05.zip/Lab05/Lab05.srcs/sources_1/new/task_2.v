`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/30/2026 04:57:09 PM
// Design Name: 
// Module Name: switches
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsm_controller (
    input clk,
    input rst,
    input [15:0] switches,
    input count_finished,
    output reg load_counter,
    output reg count_enable,
    output reg [1:0] current_state_out
);

    parameter S_WAIT  = 2'b00;
    parameter S_COUNT = 2'b01;

    reg [1:0] state, next_state;

    always @(posedge clk) begin
        if (rst)
            state <= S_WAIT;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state   = state;
        load_counter = 1'b0;
        count_enable = 1'b0;

        case (state)
            S_WAIT: begin
                if (switches != 16'd0) begin
                    load_counter = 1'b1;
                    next_state   = S_COUNT;
                end
            end

            S_COUNT: begin
                count_enable = 1'b1;
                if (count_finished) begin
                    next_state = S_WAIT;
                end
            end

            default: next_state = S_WAIT;
        endcase
        
        current_state_out = state;
    end

endmodule