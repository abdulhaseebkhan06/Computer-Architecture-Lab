`timescale 1ns / 1ps
//------------------------------------------------------------------
// Optional testbench for ControlPath_FPGA_top
// (defparam shortens the debouncer delay so simulation is fast)
//------------------------------------------------------------------
module ControlPath_FPGA_top_tb;
    reg clk = 0, btnC = 0, btnD = 0;
    reg [15:0] switches = 0;
    wire [15:0] leds;
    integer pass_count = 0, fail_count = 0, k;

    ControlPath_FPGA_top dut (.clk(clk), .switches(switches), .btnC(btnC), .btnD(btnD), .leds(leds));
    defparam dut.db_step.CYCLES = 4;
    defparam dut.db_rst.CYCLES  = 4;

    always #5 clk = ~clk;

    // expected 12-bit control word per instruction:
    // {ALUControl[3:0], ALUOp[1:0], Branch, MemtoReg, MemWrite, MemRead, ALUSrc, RegWrite}
    function [11:0] exp_ctl(input integer n);   // n = 1..15
        case (n)
            1:  exp_ctl = 12'h081;  // ADD
            2:  exp_ctl = 12'h003;  // ADDI
            3:  exp_ctl = 12'h181;  // SUB
            4:  exp_ctl = 12'h581;  // SLL
            5:  exp_ctl = 12'h681;  // SRL
            6:  exp_ctl = 12'h281;  // AND
            7:  exp_ctl = 12'h381;  // OR
            8:  exp_ctl = 12'h481;  // XOR
            9:  exp_ctl = 12'h017;  // LW
            10: exp_ctl = 12'h017;  // LH
            11: exp_ctl = 12'h017;  // LB
            12: exp_ctl = 12'h00A;  // SW
            13: exp_ctl = 12'h00A;  // SH
            14: exp_ctl = 12'h00A;  // SB
            15: exp_ctl = 12'h760;  // BEQ
            default: exp_ctl = 12'h000;
        endcase
    endfunction

    task press_step;
        begin btnC = 1; repeat (20) @(posedge clk); btnC = 0; repeat (20) @(posedge clk); end
    endtask
    task press_reset;
        begin btnD = 1; repeat (20) @(posedge clk); btnD = 0; repeat (20) @(posedge clk); end
    endtask

    task check(input [8*22-1:0] name, input [15:0] exp);
        begin
            if (leds === exp) begin pass_count = pass_count + 1; $display("PASS %-22s leds=%b", name, leds); end
            else begin fail_count = fail_count + 1; $display("FAIL %-22s leds=%b expected=%b", name, leds, exp); end
        end
    endtask

    // manual mode: opcode, funct3, funct7 bit5 on the switches
    task manual(input [8*22-1:0] name, input [6:0] opc, input [2:0] f3, input f7_5, input integer n);
        begin
            switches = {5'b00000, f7_5, f3, opc};
            repeat (12) @(posedge clk);
            check(name, {4'b0000, exp_ctl(n)});
        end
    endtask

    initial begin
        $dumpfile("ControlPath_FPGA_top.vcd");
        $dumpvars(0, ControlPath_FPGA_top_tb);
        press_reset;

        $display("--- manual mode (switches give the instruction) ---");
        manual("ADD",  7'b0110011, 3'b000, 1'b0, 1);
        manual("ADDI", 7'b0010011, 3'b000, 1'b0, 2);
        manual("SUB",  7'b0110011, 3'b000, 1'b1, 3);
        manual("SLL",  7'b0110011, 3'b001, 1'b0, 4);
        manual("SRL",  7'b0110011, 3'b101, 1'b0, 5);
        manual("AND",  7'b0110011, 3'b111, 1'b0, 6);
        manual("OR",   7'b0110011, 3'b110, 1'b0, 7);
        manual("XOR",  7'b0110011, 3'b100, 1'b0, 8);
        manual("LW",   7'b0000011, 3'b010, 1'b0, 9);
        manual("SW",   7'b0100011, 3'b010, 1'b0, 12);
        manual("BEQ",  7'b1100011, 3'b000, 1'b0, 15);
        manual("illegal opcode", 7'b1111111, 3'b000, 1'b0, 0);

        $display("--- auto mode (btnC steps through the ROM) ---");
        switches = 16'h8000;
        press_reset;
        check("auto: 1 ADD", {4'd1, exp_ctl(1)});
        for (k = 2; k <= 15; k = k + 1) begin
            press_step;
            check("auto: next instruction", {k[3:0], exp_ctl(k)});
        end
        press_step;
        check("auto: wraps to ADD", {4'd1, exp_ctl(1)});
        press_reset;
        check("reset back to ADD", {4'd1, exp_ctl(1)});

        $display("--------------------------------------------");
        $display("Tests passed: %0d   Tests failed: %0d", pass_count, fail_count);
        if (fail_count == 0) $display("ALL TESTS PASSED"); else $display("SOME TESTS FAILED");
        $finish;
    end
endmodule
