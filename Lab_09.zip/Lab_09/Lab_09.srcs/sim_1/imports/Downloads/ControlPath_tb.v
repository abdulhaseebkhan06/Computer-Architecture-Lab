`timescale 1ns / 1ps
//------------------------------------------------------------------
// Self-checking testbench for MainControl + ALUControl
//   Section 1: all 15 supported instructions (opcode/funct3/funct7 -> signals)
//   Section 2: unsupported / illegal inputs get safe values
//   Section 3: ALUControl module on its own (every ALUOp / funct3 case)
//   Section 4: exhaustive sweep of all 128 opcodes
//------------------------------------------------------------------
module ControlPath_tb;

    // ---------- inputs we drive (reg) ----------
    reg  [6:0] opcode = 7'b0;
    reg  [2:0] funct3 = 3'b0;
    reg  [6:0] funct7 = 7'b0;
    reg  [8*6-1:0] instr_name = "      ";     // text label shown in the waveform

    // ---------- outputs we observe (wire) ----------
    wire       RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
    wire [1:0] ALUOp;
    wire [3:0] ALUControl;

    // main control feeds ALU control, exactly like the real datapath
    MainControl u_main (
        .opcode(opcode), .RegWrite(RegWrite), .ALUOp(ALUOp),
        .MemRead(MemRead), .MemWrite(MemWrite), .ALUSrc(ALUSrc),
        .MemtoReg(MemtoReg), .Branch(Branch));

    ALUControl u_aluc (
        .ALUOp(ALUOp), .funct3(funct3), .funct7(funct7), .ALUControl(ALUControl));

    // ---------- second ALUControl, driven directly (Section 3) ----------
    reg  [1:0] t_aluop = 2'b00;
    reg  [2:0] t_f3    = 3'b000;
    reg  [6:0] t_f7    = 7'b0;
    wire [3:0] t_ctl;
    ALUControl u_aluc_direct (
        .ALUOp(t_aluop), .funct3(t_f3), .funct7(t_f7), .ALUControl(t_ctl));

    // ---------- third MainControl, for the opcode sweep (Section 4) ----------
    // starts at 7'h7F (not 0) so that the first sweep value, 0, is a real CHANGE;
    // combinational logic only re-evaluates on a change, otherwise outputs stay X
    reg  [6:0] sweep_op = 7'h7F;
    wire       s_rw, s_mr, s_mw, s_src, s_m2r, s_br;
    wire [1:0] s_aluop;
    MainControl u_main_sweep (
        .opcode(sweep_op), .RegWrite(s_rw), .ALUOp(s_aluop), .MemRead(s_mr),
        .MemWrite(s_mw), .ALUSrc(s_src), .MemtoReg(s_m2r), .Branch(s_br));

    integer pass_count = 0, fail_count = 0;

    // ---------- Task: apply one instruction and check all 8 outputs ----------
    task check_instr(
        input [8*6-1:0] name,
        input [6:0] opc, input [2:0] f3, input [6:0] f7,
        input e_rw, e_src, e_mr, e_mw, e_m2r, e_br,
        input [1:0] e_aluop, input [3:0] e_ctl);
        begin
            instr_name = name; opcode = opc; funct3 = f3; funct7 = f7;
            #10;                                   // let the logic settle, then look
            if ({RegWrite,ALUSrc,MemRead,MemWrite,MemtoReg,Branch,ALUOp,ALUControl} ===
                {e_rw,e_src,e_mr,e_mw,e_m2r,e_br,e_aluop,e_ctl}) begin
                pass_count = pass_count + 1;
                $display("PASS %-6s op=%b f3=%b f7=%b | RW=%b SRC=%b MR=%b MW=%b M2R=%b BR=%b ALUOp=%b ALUCtl=%b",
                         name, opc, f3, f7, RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch, ALUOp, ALUControl);
            end else begin
                fail_count = fail_count + 1;
                $display("FAIL %-6s got RW=%b SRC=%b MR=%b MW=%b M2R=%b BR=%b ALUOp=%b ALUCtl=%b",
                         name, RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch, ALUOp, ALUControl);
                $display("            expected RW=%b SRC=%b MR=%b MW=%b M2R=%b BR=%b ALUOp=%b ALUCtl=%b",
                         e_rw, e_src, e_mr, e_mw, e_m2r, e_br, e_aluop, e_ctl);
            end
            #10;                                   // hold 20 ns per instruction in the waveform
        end
    endtask

    // ---------- Task: test ALUControl on its own ----------
    task check_aluctl(input [8*14-1:0] name, input [1:0] aluop, input [2:0] f3,
                      input [6:0] f7, input [3:0] expected);
        begin
            t_aluop = aluop; t_f3 = f3; t_f7 = f7;
            #5;
            if (t_ctl === expected) begin
                pass_count = pass_count + 1;
                $display("PASS %-14s ALUOp=%b f3=%b f7=%b -> ALUControl=%b", name, aluop, f3, f7, t_ctl);
            end else begin
                fail_count = fail_count + 1;
                $display("FAIL %-14s got %b expected %b", name, t_ctl, expected);
            end
            #5;
        end
    endtask

    integer i, sweep_errors;
    reg [7:0] exp_sweep, got_sweep;

    initial begin
        $dumpfile("ControlPath.vcd");
        $dumpvars(0, ControlPath_tb);
        #20;

        $display("--- Section 1: the 15 supported instructions ---");
        //          name    opcode     f3     f7        RW SRC MR MW M2R BR  ALUOp  ALUCtl
        check_instr("ADD",  7'b0110011,3'b000,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0000);
        check_instr("ADDI", 7'b0010011,3'b000,7'b0000000, 1, 1, 0, 0, 0, 0, 2'b00, 4'b0000);
        check_instr("SUB",  7'b0110011,3'b000,7'b0100000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0001);
        check_instr("SLL",  7'b0110011,3'b001,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0101);
        check_instr("SRL",  7'b0110011,3'b101,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0110);
        check_instr("AND",  7'b0110011,3'b111,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0010);
        check_instr("OR",   7'b0110011,3'b110,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0011);
        check_instr("XOR",  7'b0110011,3'b100,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0100);
        check_instr("LW",   7'b0000011,3'b010,7'b0000000, 1, 1, 1, 0, 1, 0, 2'b00, 4'b0000);
        check_instr("LH",   7'b0000011,3'b001,7'b0000000, 1, 1, 1, 0, 1, 0, 2'b00, 4'b0000);
        check_instr("LB",   7'b0000011,3'b000,7'b0000000, 1, 1, 1, 0, 1, 0, 2'b00, 4'b0000);
        check_instr("SW",   7'b0100011,3'b010,7'b0000000, 0, 1, 0, 1, 0, 0, 2'b00, 4'b0000);
        check_instr("SH",   7'b0100011,3'b001,7'b0000000, 0, 1, 0, 1, 0, 0, 2'b00, 4'b0000);
        check_instr("SB",   7'b0100011,3'b000,7'b0000000, 0, 1, 0, 1, 0, 0, 2'b00, 4'b0000);
        check_instr("BEQ",  7'b1100011,3'b000,7'b0000000, 0, 0, 0, 0, 0, 1, 2'b01, 4'b0111);

        $display("--- Section 2: unsupported inputs get safe values ---");
        check_instr("BADOP", 7'b1111111,3'b000,7'b0000000, 0, 0, 0, 0, 0, 0, 2'b00, 4'b0000);
        check_instr("ZEROOP",7'b0000000,3'b101,7'b0100000, 0, 0, 0, 0, 0, 0, 2'b00, 4'b0000);
        check_instr("SLT*",  7'b0110011,3'b010,7'b0000000, 1, 0, 0, 0, 0, 0, 2'b10, 4'b0000);
        opcode = 0; funct3 = 0; funct7 = 0; instr_name = "      ";

        $display("--- Section 3: ALUControl module on its own ---");
        check_aluctl("op00 ignores f", 2'b00, 3'b111, 7'b0100000, 4'b0000);
        check_aluctl("op01 -> BEQ",    2'b01, 3'b000, 7'b0000000, 4'b0111);
        check_aluctl("op10 ADD",       2'b10, 3'b000, 7'b0000000, 4'b0000);
        check_aluctl("op10 SUB",       2'b10, 3'b000, 7'b0100000, 4'b0001);
        check_aluctl("op10 SLL",       2'b10, 3'b001, 7'b0000000, 4'b0101);
        check_aluctl("op10 XOR",       2'b10, 3'b100, 7'b0000000, 4'b0100);
        check_aluctl("op10 SRL",       2'b10, 3'b101, 7'b0000000, 4'b0110);
        check_aluctl("op10 OR",        2'b10, 3'b110, 7'b0000000, 4'b0011);
        check_aluctl("op10 AND",       2'b10, 3'b111, 7'b0000000, 4'b0010);
        check_aluctl("op10 f3=010",    2'b10, 3'b010, 7'b0000000, 4'b0000);
        check_aluctl("op11 unused",    2'b11, 3'b111, 7'b0100000, 4'b0000);

        $display("--- Section 4: sweep all 128 opcodes ---");
        sweep_errors = 0;
        for (i = 0; i < 128; i = i + 1) begin
            sweep_op = i[6:0];
            #1;
            case (i)                                   // expected {RW,SRC,MR,MW,M2R,BR,ALUOp}
                51:      exp_sweep = 8'h82;            // R-type
                19:      exp_sweep = 8'hC0;            // ADDI
                3:       exp_sweep = 8'hE8;            // load
                35:      exp_sweep = 8'h50;            // store
                99:      exp_sweep = 8'h05;            // branch
                default: exp_sweep = 8'h00;            // everything else: all off
            endcase
            got_sweep = {s_rw, s_src, s_mr, s_mw, s_m2r, s_br, s_aluop};
            if (got_sweep !== exp_sweep) sweep_errors = sweep_errors + 1;
        end
        if (sweep_errors == 0) begin
            pass_count = pass_count + 1;
            $display("PASS only the 5 valid opcodes enable anything; the other 123 give all zeros");
        end else begin
            fail_count = fail_count + 1;
            $display("FAIL opcode sweep: %0d wrong", sweep_errors);
        end

        #20;
        $display("--------------------------------------------");
        $display("Tests passed: %0d   Tests failed: %0d", pass_count, fail_count);
        if (fail_count == 0) $display("ALL TESTS PASSED");
        else                 $display("SOME TESTS FAILED");
        $finish;
    end
endmodule
