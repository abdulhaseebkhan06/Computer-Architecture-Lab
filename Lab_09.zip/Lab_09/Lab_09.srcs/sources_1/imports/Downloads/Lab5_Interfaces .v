`timescale 1ns / 1ps
//------------------------------------------------------------------
// STAND-IN versions of the Lab 5 provided modules.
// Port lists are copied from the lab manual, so your own provided
// files can replace this file with no other changes.
// NOTE: the manual's module names are swapped relative to function:
//   module "switches" has the 'leds' output  -> it WRITES the LEDs
//   module "leds"     has the 'switches' input -> it READS the switches
//------------------------------------------------------------------

// LED output interface (write only)
module switches(
    input         clk,
    input         rst,
    input  [31:0] writeData,
    input         writeEnable,
    input         readEnable,
    input  [29:0] memAddress,
    output reg [31:0] readData = 0,   // not to be read
    output reg [15:0] leds = 16'b0
);
    always @(posedge clk) begin
        if (rst)             leds <= 16'b0;
        else if (writeEnable) leds <= writeData[15:0];
    end
endmodule

// Switch input interface (read only)
module leds(
    input         clk, rst,
    input  [15:0] btns,
    input  [31:0] writeData,          // not to be written
    input         writeEnable,        // not to be used
    input         readEnable,
    input  [29:0] memAddress,
    input  [15:0] switches,
    output     [31:0] readData
);
    assign readData = readEnable ? {16'b0, switches} : 32'b0;
endmodule

// Button debouncer: 2-FF synchroniser + stable-for-N-cycles filter
module debouncer #(
    parameter CYCLES = 1_000_000      // 10 ms at 100 MHz
)(
    input      clk,
    input      pbin,
    output reg pbout = 1'b0
);
    reg s0 = 1'b0, s1 = 1'b0;
    reg [31:0] cnt = 32'd0;
    always @(posedge clk) begin
        s0 <= pbin;
        s1 <= s0;
        if (s1 == pbout)
            cnt <= 32'd0;
        else begin
            cnt <= cnt + 1'b1;
            if (cnt == CYCLES - 1) begin
                pbout <= s1;
                cnt   <= 32'd0;
            end
        end
    end
endmodule
