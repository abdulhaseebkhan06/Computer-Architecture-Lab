`timescale 1ns / 1ps
//------------------------------------------------------------------
// Lab 9, Task 3 - FPGA top level (Basys 3)
//
// INPUT  switches (manual mode, sw[15] = 0):
//   sw[6:0]   opcode            sw[9:7]  funct3
//   sw[10]    funct7 bit 5 (the only funct7 bit that matters: ADD vs SUB)
//   sw[15]    0 = manual (LEDs follow the switches)
//             1 = auto   (each press of btnC steps through the 15 instructions)
// BUTTONS btnC = next instruction (auto mode)     btnD = reset
//
// OUTPUT LEDs:
//   led[0] RegWrite   led[1] ALUSrc    led[2] MemRead  led[3] MemWrite
//   led[4] MemtoReg   led[5] Branch    led[7:6] ALUOp  led[11:8] ALUControl
//   led[15:12] instruction number 1..15 in auto mode, 0000 in manual mode
//   (1 ADD 2 ADDI 3 SUB 4 SLL 5 SRL 6 AND 7 OR 8 XOR
//    9 LW 10 LH 11 LB 12 SW 13 SH 14 SB 15 BEQ)
//
// FSM (runs forever):  S_LOAD -> S_DECODE -> S_SHOW -> S_LOAD ...
//   S_LOAD   : latch the instruction fields (from the switches or the ROM)
//   S_DECODE : the control logic has settled, capture its outputs
//   S_SHOW   : write the captured value to the LED interface
//------------------------------------------------------------------
module ControlPath_FPGA_top (
    input         clk,            // 100 MHz
    input  [15:0] switches,
    input         btnC,           // next instruction (auto mode)
    input         btnD,           // reset
    output [15:0] leds
);
    // ---------- buttons: debounce, then one pulse per press (Lab 5 debouncer) ----------
    wire step_db, rst;
    debouncer db_step (.clk(clk), .pbin(btnC), .pbout(step_db));
    debouncer db_rst  (.clk(clk), .pbin(btnD), .pbout(rst));

    reg step_d = 1'b0;
    always @(posedge clk) step_d <= step_db;
    wire step = step_db & ~step_d;

    // ---------- switches: 2-FF synchroniser, then Lab 5 switch interface ----------
    reg [15:0] sw_m = 16'b0, sw_s = 16'b0;
    always @(posedge clk) begin
        sw_m <= switches;
        sw_s <= sw_m;
    end

    wire [31:0] sw_word;
    leds u_sw_if (                       // Lab 5 module named "leds": it READS the switches
        .clk(clk), .rst(rst), .btns(16'b0),
        .writeData(32'b0), .writeEnable(1'b0),
        .readEnable(1'b1),
        .memAddress(30'b0),
        .switches(sw_s),
        .readData(sw_word)
    );

    wire        auto_mode = sw_word[15];

    // ---------- instruction ROM for auto mode: {funct7[5], funct3, opcode} ----------
    reg [3:0]  idx = 4'd0;               // 0..14

    function [10:0] rom_lookup(input [3:0] i);
        case (i)
            4'd0:    rom_lookup = {1'b0, 3'b000, 7'b0110011};   // ADD
            4'd1:    rom_lookup = {1'b0, 3'b000, 7'b0010011};   // ADDI
            4'd2:    rom_lookup = {1'b1, 3'b000, 7'b0110011};   // SUB
            4'd3:    rom_lookup = {1'b0, 3'b001, 7'b0110011};   // SLL
            4'd4:    rom_lookup = {1'b0, 3'b101, 7'b0110011};   // SRL
            4'd5:    rom_lookup = {1'b0, 3'b111, 7'b0110011};   // AND
            4'd6:    rom_lookup = {1'b0, 3'b110, 7'b0110011};   // OR
            4'd7:    rom_lookup = {1'b0, 3'b100, 7'b0110011};   // XOR
            4'd8:    rom_lookup = {1'b0, 3'b010, 7'b0000011};   // LW
            4'd9:    rom_lookup = {1'b0, 3'b001, 7'b0000011};   // LH
            4'd10:   rom_lookup = {1'b0, 3'b000, 7'b0000011};   // LB
            4'd11:   rom_lookup = {1'b0, 3'b010, 7'b0100011};   // SW
            4'd12:   rom_lookup = {1'b0, 3'b001, 7'b0100011};   // SH
            4'd13:   rom_lookup = {1'b0, 3'b000, 7'b0100011};   // SB
            4'd14:   rom_lookup = {1'b0, 3'b000, 7'b1100011};   // BEQ
            default: rom_lookup = {1'b0, 3'b000, 7'b0110011};
        endcase
    endfunction

    // continuous assignment: always evaluated, even before idx first changes
    wire [10:0] rom = rom_lookup(idx);

    always @(posedge clk) begin
        if (rst)                       idx <= 4'd0;
        else if (step && auto_mode)    idx <= (idx == 4'd14) ? 4'd0 : idx + 4'd1;
    end

    // ---------- the control path under test ----------
    reg  [6:0] opcode_r  = 7'b0;
    reg  [2:0] funct3_r  = 3'b0;
    reg        funct7_5_r = 1'b0;
    reg  [3:0] instr_no  = 4'd0;

    wire       RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
    wire [1:0] ALUOp;
    wire [3:0] ALUCtl;

    MainControl u_main (
        .opcode(opcode_r), .RegWrite(RegWrite), .ALUOp(ALUOp),
        .MemRead(MemRead), .MemWrite(MemWrite), .ALUSrc(ALUSrc),
        .MemtoReg(MemtoReg), .Branch(Branch));

    ALUControl u_aluc (
        .ALUOp(ALUOp), .funct3(funct3_r),
        .funct7({1'b0, funct7_5_r, 5'b00000}),
        .ALUControl(ALUCtl));

    // ---------- FSM ----------
    localparam [1:0] S_LOAD = 2'd0, S_DECODE = 2'd1, S_SHOW = 2'd2;
    reg [1:0]  state   = S_LOAD;
    reg [11:0] ctl_reg = 12'b0;          // {ALUControl, ALUOp, Branch, MemtoReg, MemWrite, MemRead, ALUSrc, RegWrite}

    always @(posedge clk) begin
        if (rst) begin
            state <= S_LOAD;  ctl_reg <= 12'b0;  instr_no <= 4'd0;
            opcode_r <= 7'b0; funct3_r <= 3'b0;  funct7_5_r <= 1'b0;
        end else begin
            case (state)
                S_LOAD: begin
                    if (auto_mode) begin
                        {funct7_5_r, funct3_r, opcode_r} <= rom;
                        instr_no <= idx + 4'd1;
                    end else begin
                        {funct7_5_r, funct3_r, opcode_r} <= sw_word[10:0];
                        instr_no <= 4'd0;
                    end
                    state <= S_DECODE;
                end
                S_DECODE: begin
                    ctl_reg <= {ALUCtl, ALUOp, Branch, MemtoReg, MemWrite, MemRead, ALUSrc, RegWrite};
                    state   <= S_SHOW;
                end
                S_SHOW:  state <= S_LOAD;
                default: state <= S_LOAD;
            endcase
        end
    end

    // ---------- LEDs through the Lab 5 LED interface ----------
    switches u_led_if (                  // Lab 5 module named "switches": it WRITES the LEDs
        .clk(clk), .rst(rst),
        .writeData({16'b0, instr_no, ctl_reg}),
        .writeEnable(state == S_SHOW),
        .readEnable(1'b0),
        .memAddress(30'b0),
        .readData(),
        .leds(leds)
    );
endmodule
