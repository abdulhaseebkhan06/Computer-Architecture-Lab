`timescale 1ns / 1ps
//------------------------------------------------------------------
// Main control unit (combinational): opcode -> control signals
// Supported opcodes:
//   0110011 R-type  : ADD SUB SLL SRL AND OR XOR
//   0010011 I-type  : ADDI
//   0000011 Load    : LW LH LB
//   0100011 Store   : SW SH SB
//   1100011 Branch  : BEQ
// ALUOp:  00 = add        (addi, loads, stores)
//         01 = subtract   (beq)
//         10 = use funct3/funct7 (R-type)
// Don't-care (X) entries and unknown opcodes get SAFE values:
//   no register write, no memory access, no branch.
//------------------------------------------------------------------
module MainControl (
    input      [6:0] opcode,
    output reg       RegWrite,
    output reg [1:0] ALUOp,
    output reg       MemRead,
    output reg       MemWrite,
    output reg       ALUSrc,
    output reg       MemtoReg,
    output reg       Branch
);
    localparam OP_RTYPE  = 7'b0110011;
    localparam OP_ITYPE  = 7'b0010011;
    localparam OP_LOAD   = 7'b0000011;
    localparam OP_STORE  = 7'b0100011;
    localparam OP_BRANCH = 7'b1100011;

    always @(*) begin
        // safe defaults (also what an unknown opcode produces)
        RegWrite = 1'b0;  ALUSrc  = 1'b0;  MemRead = 1'b0;
        MemWrite = 1'b0;  MemtoReg = 1'b0; Branch  = 1'b0;
        ALUOp    = 2'b00;

        case (opcode)
            OP_RTYPE:  begin RegWrite = 1'b1; ALUOp = 2'b10; end
            OP_ITYPE:  begin RegWrite = 1'b1; ALUSrc = 1'b1; ALUOp = 2'b00; end
            OP_LOAD:   begin RegWrite = 1'b1; ALUSrc = 1'b1; MemRead = 1'b1;
                             MemtoReg = 1'b1; ALUOp = 2'b00; end
            OP_STORE:  begin ALUSrc = 1'b1; MemWrite = 1'b1; ALUOp = 2'b00; end
            OP_BRANCH: begin Branch = 1'b1; ALUOp = 2'b01; end
            default: ;
        endcase
    end
endmodule
