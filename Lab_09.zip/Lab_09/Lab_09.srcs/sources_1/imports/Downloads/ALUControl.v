`timescale 1ns / 1ps
//------------------------------------------------------------------
// ALU control unit (combinational)
// Inputs : ALUOp[1:0] from MainControl, funct3, funct7
// Output : ALUControl[3:0], using the SAME codes as the Lab 6 ALU
//------------------------------------------------------------------
module ALUControl (
    input      [1:0] ALUOp,
    input      [2:0] funct3,
    input      [6:0] funct7,
    output reg [3:0] ALUControl
);
    localparam ALU_ADD = 4'b0000;
    localparam ALU_SUB = 4'b0001;
    localparam ALU_AND = 4'b0010;
    localparam ALU_OR  = 4'b0011;
    localparam ALU_XOR = 4'b0100;
    localparam ALU_SLL = 4'b0101;
    localparam ALU_SRL = 4'b0110;
    localparam ALU_BEQ = 4'b0111;   // A - B, Zero flag tells equality

    always @(*) begin
        case (ALUOp)
            2'b00: ALUControl = ALU_ADD;      // addi, lw/lh/lb, sw/sh/sb
            2'b01: ALUControl = ALU_BEQ;      // beq
            2'b10: begin                      // R-type: look at funct3/funct7
                case (funct3)
                    3'b000:  ALUControl = (funct7 == 7'b0100000) ? ALU_SUB : ALU_ADD;
                    3'b001:  ALUControl = ALU_SLL;
                    3'b100:  ALUControl = ALU_XOR;
                    3'b101:  ALUControl = ALU_SRL;
                    3'b110:  ALUControl = ALU_OR;
                    3'b111:  ALUControl = ALU_AND;
                    default: ALUControl = ALU_ADD;   // unsupported: safe default
                endcase
            end
            default: ALUControl = ALU_ADD;    // ALUOp = 11 is unused
        endcase
    end
endmodule
