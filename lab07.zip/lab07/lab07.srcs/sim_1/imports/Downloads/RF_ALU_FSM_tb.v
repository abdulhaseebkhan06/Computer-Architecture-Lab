`timescale 1ns/1ps

module RF_ALU_FSM_tb;

    reg clk, rst, start;
    reg [4:0] view_reg;
    wire [31:0] view_data;
    wire [3:0] state;

    rf_alu_fsm uut(clk, rst, start, view_reg, view_data, state);

    always #5 clk = ~clk;

    task check(input [4:0] r, input [31:0] expected);
        begin
            view_reg = r;
            #1;
            if (view_data === expected)
                $display("PASS: x%0d = %h", r, view_data);
            else
                $display("FAIL: x%0d = %h expected %h", r, view_data, expected);
        end
    endtask

    initial begin
        $dumpfile("RF_ALU_FSM_tb.vcd");
        $dumpvars(0, RF_ALU_FSM_tb);
        clk = 0; rst = 1; start = 0; view_reg = 0;
        #12 rst = 0;
        #10 start = 1;

        // wait for DONE state (14)
        wait (state == 4'd14);
        @(posedge clk); #1;

        check(1,  32'h10101010);
        check(2,  32'h01010101);
        check(3,  32'h00000005);
        check(4,  32'h11111111);  // ADD
        check(5,  32'h0F0F0F0F);  // SUB
        check(6,  32'h00000000);  // AND
        check(7,  32'h11111111);  // OR
        check(8,  32'h11111111);  // XOR
        check(9,  32'h20202020);  // SLL by 1
        check(10, 32'h08080808);  // SRL by 1
        check(11, 32'h00000001);  // BEQ flag
        check(12, 32'h11111111);  // read after write value
        check(13, 32'h00000001);  // read after write flag
        check(0,  32'h00000000);  // x0

        $display("RF_ALU_FSM_tb done");
        $finish;
    end

endmodule
