`timescale 1ns/1ps

module RegisterFile_tb;

    reg clk, rst, WriteEnable;
    reg [4:0] rs1, rs2, rd;
    reg [31:0] WriteData;
    wire [31:0] ReadData1, ReadData2;

    RegisterFile uut(clk, rst, WriteEnable, rs1, rs2, rd, WriteData, ReadData1, ReadData2);

    always #5 clk = ~clk;

    task check(input [31:0] got, input [31:0] expected, input [255:0] name);
        begin
            if (got === expected)
                $display("PASS: %0s", name);
            else
                $display("FAIL: %0s got %h expected %h", name, got, expected);
        end
    endtask

    initial begin
        $dumpfile("RegisterFile_tb.vcd");
        $dumpvars(0, RegisterFile_tb);
        clk = 0; rst = 1; WriteEnable = 0;
        rs1 = 0; rs2 = 0; rd = 0; WriteData = 0;
        #12 rst = 0;

        // 1. write x5 and read back
        rd = 5; WriteData = 32'hDEADBEEF; WriteEnable = 1;
        @(posedge clk); #1 WriteEnable = 0;
        rs1 = 5;
        #1 check(ReadData1, 32'hDEADBEEF, "write x5 read port 1");
        rs2 = 5;
        #1 check(ReadData2, 32'hDEADBEEF, "write x5 read port 2");

        // 2. write to x0 is ignored
        rd = 0; WriteData = 32'hFFFFFFFF; WriteEnable = 1;
        @(posedge clk); #1 WriteEnable = 0;
        rs1 = 0;
        #1 check(ReadData1, 32'h0, "x0 stays zero");

        // 3. both read ports at once
        rd = 7; WriteData = 32'h12345678; WriteEnable = 1;
        @(posedge clk); #1 WriteEnable = 0;
        rs1 = 5; rs2 = 7;
        #1 check(ReadData1, 32'hDEADBEEF, "two reads port 1");
        check(ReadData2, 32'h12345678, "two reads port 2");

        // 4. overwrite
        rd = 5; WriteData = 32'hCAFEF00D; WriteEnable = 1;
        @(posedge clk); #1 WriteEnable = 0;
        #1 check(ReadData1, 32'hCAFEF00D, "overwrite x5");

        // 5. no write when WriteEnable is 0
        rd = 7; WriteData = 32'h0BADBAD0; WriteEnable = 0;
        @(posedge clk); #1;
        check(ReadData2, 32'h12345678, "no write when disabled");

        // 6. reset clears registers
        rst = 1;
        @(posedge clk); #1 rst = 0;
        check(ReadData1, 32'h0, "reset clears x5");
        check(ReadData2, 32'h0, "reset clears x7");

        $display("RegisterFile_tb done");
        $finish;
    end

endmodule
