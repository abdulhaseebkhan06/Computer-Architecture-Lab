module rf_alu_fsm(
    input clk,
    input rst,
    input start,
    input [4:0] view_reg,
    output [31:0] view_data,
    output reg [3:0] state
);

    localparam IDLE = 4'd0,  W1 = 4'd1,  W2 = 4'd2,  W3 = 4'd3,
               S_ADD = 4'd4, S_SUB = 4'd5, S_AND = 4'd6, S_OR = 4'd7,
               S_XOR = 4'd8, S_SLL = 4'd9, S_SRL = 4'd10,
               BEQ_CHK = 4'd11, RAW_WR = 4'd12, RAW_CHK = 4'd13, DONE = 4'd14;

    reg        WriteEnable;
    reg [4:0]  rs1, rs2, rd;
    reg [3:0]  ALUControl;
    reg        useConst;
    reg [31:0] constData;

    wire [31:0] ReadData1, ReadData2, ALUResult;
    wire Zero;
    wire [31:0] WriteData = useConst ? constData : ALUResult;

    RegisterFile rf(clk, rst, WriteEnable, rs1, rs2, rd, WriteData, ReadData1, ReadData2);
    ALU alu(ReadData1, ReadData2, ALUControl, ALUResult, Zero);

    assign view_data = ReadData1;

    // state register
    always @(posedge clk) begin
        if (rst)
            state <= IDLE;
        else begin
            case (state)
                IDLE:    if (start) state <= W1;
                DONE:    state <= DONE;
                default: state <= state + 1;
            endcase
        end
    end

    // outputs of each state
    always @(*) begin
        WriteEnable = 0; rs1 = 0; rs2 = 0; rd = 0;
        ALUControl = 4'b0000; useConst = 0; constData = 0;
        case (state)
            W1: begin WriteEnable = 1; rd = 1; useConst = 1; constData = 32'h10101010; end
            W2: begin WriteEnable = 1; rd = 2; useConst = 1; constData = 32'h01010101; end
            W3: begin WriteEnable = 1; rd = 3; useConst = 1; constData = 32'h00000005; end
            S_ADD: begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 4;  ALUControl = 4'b0000; end
            S_SUB: begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 5;  ALUControl = 4'b0001; end
            S_AND: begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 6;  ALUControl = 4'b0010; end
            S_OR:  begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 7;  ALUControl = 4'b0011; end
            S_XOR: begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 8;  ALUControl = 4'b0100; end
            S_SLL: begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 9;  ALUControl = 4'b0101; end
            S_SRL: begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 10; ALUControl = 4'b0110; end
            // BEQ check: x1 - x1 == 0, so flag x11 = 1
            BEQ_CHK: begin WriteEnable = Zero; rs1 = 1; rs2 = 1; rd = 11; ALUControl = 4'b0001;
                           useConst = 1; constData = 32'd1; end
            // read after write: write x12 = x1 + x2, then compare it with x4 in the next cycle
            RAW_WR:  begin WriteEnable = 1; rs1 = 1; rs2 = 2; rd = 12; ALUControl = 4'b0000; end
            RAW_CHK: begin WriteEnable = Zero; rs1 = 12; rs2 = 4; rd = 13; ALUControl = 4'b0001;
                           useConst = 1; constData = 32'd1; end
            DONE:    begin rs1 = view_reg; end
        endcase
    end

endmodule
