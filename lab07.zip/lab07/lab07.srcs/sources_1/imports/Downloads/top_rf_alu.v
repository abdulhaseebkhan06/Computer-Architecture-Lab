module top_rf_alu(
    input clk,
    input btnC,            // reset
    input [15:0] sw,
    output [15:0] led
);

    wire [31:0] view_data;
    wire [3:0] state;

    // sw[15] = start, sw[4:0] = register to view, sw[5] = 0 low bits / 1 upper bits
    rf_alu_fsm fsm(clk, btnC, sw[15], sw[4:0], view_data, state);

    assign led[15:12] = state;
    assign led[11:0]  = sw[5] ? view_data[31:20] : view_data[11:0];

endmodule
