`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/28/2026 05:45:31 PM
// Design Name: 
// Module Name: instructionMemory_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module instructionMemory_tb;
reg [31:0] addr;
wire [31:0] inst;
integer i;

instructionMemory uut(.instAddress(addr), .instruction(inst));

initial begin
    for (i = 0; i < 28; i = i + 1) begin
        addr = i*4;
        #10;
        $display("addr=%0d inst=%h", addr, inst);
    end
    $finish;
end
endmodule